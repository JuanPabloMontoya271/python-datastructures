class binary_tree:
    def __init__(self):
        print('this is a binary tree')
if __name__ == '__main__':
    binary_tree()